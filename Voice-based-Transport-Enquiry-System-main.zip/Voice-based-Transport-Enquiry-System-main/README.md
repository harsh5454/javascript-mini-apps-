# Voice-based-Transport-Enquiry-System


# VoiceEnquiry
![alt text](https://robohash.org/1?200x200)

Project done for dbms subject

Stack Used:
* REACT JS + Node JS + MySQL + Express JS

React JS is available in VoiceEnquirySystem folder
Node JS is available in VoiceEnquiryBackEnd folder

To run the app,
 Fork it. Install the npm modules using npm install . 
 
 
In server.js file, edit the connection details of your host Database and execute commands in Database.txt. Now you are ready to go.

Type node server.js to run the server in default port: 3000



